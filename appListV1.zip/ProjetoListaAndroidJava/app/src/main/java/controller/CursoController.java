package controller;

public class CursoController {
}
