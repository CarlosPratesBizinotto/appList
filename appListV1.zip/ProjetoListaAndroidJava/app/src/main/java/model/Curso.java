package model;

public class Curso {

   public Curso(){

   }

}
